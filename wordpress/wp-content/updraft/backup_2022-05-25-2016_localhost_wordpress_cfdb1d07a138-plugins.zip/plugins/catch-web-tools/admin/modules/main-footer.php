			</div><!-- #dashboard -->
		</div><!-- .catchp_widget_settings -->

        <?php require_once plugin_dir_path( dirname( __FILE__ ) ) . '/modules/sidebar.php'; ?>
    </div> <!-- .catchp-content-wrapper -->

    <?php require_once plugin_dir_path( dirname( __FILE__ ) ) . '/modules/footer.php'; ?>
</div><!-- .wrap -->