jQuery(document).ready(function($){ 
    var our_themes = '<li><a href="#" data-sort="catchthemes">Catch Themes</a></li>'; 
    $('.filter-links').append( our_themes ); 
});